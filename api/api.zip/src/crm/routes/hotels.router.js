const { ROLES,ROLE } = require("../../common/constants");
const { hotelsController } = require("../controllers");
const { hotel, create } = require("../routes/validations").hotelValidations;
const router = require("express").Router();
const { validationMiddleware,authMiddleware, authRole } = require("../routes//middlewares/index");

router.post("/", [authMiddleware,authRole(ROLE.ADMIN) , validationMiddleware(create)], hotelsController.createHotel);

router.get("/", hotelsController.getRecords);
router.get("/paginate", hotelsController.getRecords);
router.get("/countByCity", hotelsController.getCountByCity);
router.get("/countByType", hotelsController.getCountByType);



router.delete("/:id", hotelsController.deleteRecordById);
router.get("/find/:id", hotelsController.getRecordById);
router.put("/:id", hotelsController.updateRecord);

module.exports = router;
