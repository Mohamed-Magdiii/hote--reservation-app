/* eslint-disable object-property-newline */

module.exports = {

};
