const { RoomModel , HotelModel } = require("../models");
const hotelService = require("../services/hotels.service")
const Cruds = require("./Cruds");

class roomService extends Cruds {
    async createRoom(params, hotelId){
    const newRoom = await this.create(params)
    await HotelModel.Model.findByIdAndUpdate(hotelId, {$push: {rooms:newRoom._id}})
    return newRoom
    }
    async deleteRoom(id, hotelId){
        const rec = await this.deleteById(id)
        await hotelService.updateByIdWithPull(hotelId, {rooms:id})
        return rec
    }
}

module.exports = new roomService(RoomModel.Model, RoomModel.Schema)