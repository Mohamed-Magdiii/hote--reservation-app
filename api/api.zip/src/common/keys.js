module.exports = {
  port: process.env.PORT,
  mongoUrl: process.env.MONGO_URI,
  jwtKey: process.env.JWT_KEY,
};